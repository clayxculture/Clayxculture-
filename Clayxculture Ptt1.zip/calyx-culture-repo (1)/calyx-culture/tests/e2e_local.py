import json,os
from playwright.sync_api import sync_playwright
HERE=os.path.dirname(os.path.abspath(__file__));SITE=os.path.join(HERE,'..','site','index.html')
cats=['Hoodies','Denim']
prods=[{'id':i,'name':f'Item {i}','category':cats[i%2],'kind':'hood','price':900+i*50,'compare_at':None,'badge':None,'colors':['Black'],'image_url':None,'stock':None,'is_demo':False,'created_at':'2026-11-10T00:00:00Z'} for i in range(1,7)]
errs=[]
def mk(ctx):
    def route(r):
        u=r.request.url
        def ok(x): r.fulfill(status=200,content_type='application/json',body=json.dumps(x))
        if '/rest/v1/products' in u: ok(prods)
        elif 'rpc/home_extras' in u: ok({'stats':{},'best':[],'latest':[]})
        elif 'supabase' in u: ok([])
        elif u.startswith('file:') or u.startswith('http://localhost'): r.continue_()
        else: r.abort()
    ctx.route('**/*',route)
with sync_playwright() as p:
    b=p.chromium.launch()
    # 1) opened straight from a file (like content:// on a phone)
    ctx=b.new_context(viewport={'width':390,'height':844},service_workers='block');ctx.add_init_script("localStorage.setItem('cc_wel',String(Date.now()))");mk(ctx)
    pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file://'+os.path.abspath(SITE));pg.wait_for_timeout(900)
    assert 'not found' not in pg.inner_text('body').lower(),'file mode shows not found';assert pg.locator('#grid .card').count()==6,'home cards'
    pg.locator('#tiles a').first.click();pg.wait_for_timeout(400);assert not pg.locator('#col').is_hidden() and '#/shop/' in pg.url,'category in file mode '+pg.url
    pg.go_back();pg.wait_for_timeout(400);assert pg.locator('#col').is_hidden(),'back to home'
    pg.locator('#grid .card .open').first.click();pg.wait_for_timeout(500);assert not pg.locator('#pdp').is_hidden() and pg.locator('#pdpc .sz').count()==4,'product page in file mode'
    pg.evaluate("document.getElementById('pdpc').scrollIntoView();scrollTo(0,0)");pg.wait_for_timeout(300)
    # sticky buy bar visible while add button is below the fold, add works with size prompt
    pg.set_viewport_size({'width':390,'height':500});pg.wait_for_timeout(500)
    if pg.locator('#sab').is_visible(): pg.click('#sab [data-addq]');pg.wait_for_timeout(300);assert 'Pick a size' in pg.inner_text('#ze'),'sticky bar prompts size'
    pg.click('#pdpc .sz[data-z=M]');pg.click('#pdpc [data-addq]');pg.wait_for_timeout(400);assert pg.inner_text('#cc')=='1';assert 'View bag' in pg.inner_text('#toast'),'toast action'
    pg.click('#toast .ta');pg.wait_for_timeout(300);assert pg.locator('#cart[open]').count()==1,'view bag opens cart'
    ctx.close()
    # 2) host without rewrites: /?r=/shop/hoodies
    ctx=b.new_context(viewport={'width':390,'height':844},service_workers='block');ctx.add_init_script("localStorage.setItem('cc_wel',String(Date.now()))");mk(ctx)
    pg=ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8077/?r=/shop/hoodies');pg.wait_for_timeout(900)
    assert pg.url.endswith('/shop/hoodies') and not pg.locator('#col').is_hidden() and 'Hoodies' in pg.title(),'r param restore '+pg.url
    print('local + redirect modes ok',errs);b.close()
