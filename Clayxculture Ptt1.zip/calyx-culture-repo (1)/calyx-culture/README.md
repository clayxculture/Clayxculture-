# Calyx Culture store

Streetwear store for Calyx Culture, Srinagar. Static website (no build step) + Supabase database + Cloudinary images.

```
site/        <- the website. Upload THIS folder to Netlify or Cloudflare Pages.
  index.html          storefront (home, shop, categories, search, product pages, bag, checkout, chat)
  admin/              owner panel (index.html + admin.js)  ->  yourdomain/admin/
  policies.html       returns, shipping, payments, terms, privacy, grievance
  404.html offline.html sw.js manifest.webmanifest icons
  _headers _redirects security headers and page rewrites (Netlify and Cloudflare Pages read these)
supabase/
  schema.sql          whole database: tables, rules, security (run once in a new Supabase project)
  seed.sql            starter settings, FAQ and your admin email
  functions/          2 edge functions for secure Cloudinary uploads
docs/                 ADMIN-GUIDE, SECURITY, LAUNCH-CHECKLIST, ROADMAP
tests/                browser tests (mocked backend). ./tests/run-all.sh
archive/              the very first single-file preview (not connected to anything)
```

## Fastest way to try it (2 minutes)
1. Go to app.netlify.com, **Add new site, Deploy manually**, and drag the **`site`** folder in.
2. Open the link. The store works right away with your existing Supabase project (Cash on Delivery and WhatsApp orders).
3. To put it on GitHub first: push this whole folder, then in Netlify choose **Import from Git**. `netlify.toml` already points to `site/`.

Cloudflare Pages works the same way (build command empty, output directory `site`).
GitHub Pages is **not** suitable: it cannot do the page rewrites or security headers.

## Preview on your phone or computer without hosting
Double-tap `site/index.html` (it opens straight from the Files app too). The store, search, categories, product pages, bag and chat all work; pages use a `#/` address in this mode. The admin panel and photo upload need the hosted site because Google sign-in only works on a real web address.

## Before real customers
Follow `docs/LAUNCH-CHECKLIST.md`. The three must-do items: Google sign-in for the admin, the Cloudinary secrets for photo upload, and the seller details for the Policies page.

## Using a different Supabase project
Edit the two values near the top of `site/index.html` (`SB` and `KEY`), `site/admin/admin.js` (`SB` and `KEY`) and `site/policies.html`, run `supabase/schema.sql` then `supabase/seed.sql`, deploy the two functions in `supabase/functions/`, and update the URLs in `site/_headers`. The Supabase URL and publishable key are meant to be public. Never put a secret key in `site/`.
