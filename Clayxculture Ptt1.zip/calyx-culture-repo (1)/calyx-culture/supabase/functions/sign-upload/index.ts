// Admin-only: returns a signed Cloudinary upload (product photos and hero video).
// Secrets (set in Supabase > Edge Functions > Secrets): CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET, CLOUDINARY_CLOUD_NAME (optional)
const ORIGINS=['https://clayxculture.in','https://www.clayxculture.in'];
const okO=(o:string)=>ORIGINS.includes(o)||/^https:\/\/[a-z0-9-]+\.(pages\.dev|netlify\.app)$/.test(o);
const hex=(b:ArrayBuffer)=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');
Deno.serve(async(req:Request)=>{
 const o=req.headers.get('origin')||'';
 const h={'Access-Control-Allow-Origin':okO(o)?o:ORIGINS[0],'Access-Control-Allow-Headers':'authorization,content-type,apikey','Access-Control-Allow-Methods':'POST,OPTIONS','Vary':'Origin','Content-Type':'application/json'};
 const out=(b:unknown,s=200)=>new Response(JSON.stringify(b),{status:s,headers:h});
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:h});
 if(req.method!=='POST'||!okO(o))return out({error:'forbidden'},403);
 const auth=req.headers.get('authorization')||'';
 if(!auth.startsWith('Bearer '))return out({error:'forbidden'},403);
 const r=await fetch(Deno.env.get('SUPABASE_URL')+'/rest/v1/rpc/is_admin',{method:'POST',headers:{apikey:Deno.env.get('SUPABASE_ANON_KEY')||'',Authorization:auth,'Content-Type':'application/json'},body:'{}'});
 if(!r.ok||(await r.json())!==true)return out({error:'forbidden'},403);
 const secret=Deno.env.get('CLOUDINARY_API_SECRET'),apiKey=Deno.env.get('CLOUDINARY_API_KEY'),cloud=Deno.env.get('CLOUDINARY_CLOUD_NAME')||'soa4brgh';
 if(!secret||!apiKey)return out({error:'not_configured'},500);
 const ts=Math.floor(Date.now()/1000),folder='calyx/p';
 const sig=hex(await crypto.subtle.digest('SHA-1',new TextEncoder().encode('folder='+folder+'&timestamp='+ts+secret)));
 return out({signature:sig,timestamp:ts,api_key:apiKey,cloud_name:cloud,folder});
});
