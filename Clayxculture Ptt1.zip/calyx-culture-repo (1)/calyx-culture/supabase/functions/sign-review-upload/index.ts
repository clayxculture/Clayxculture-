// Customers: signed Cloudinary upload for ONE review photo, only if the order is delivered,
// belongs to the phone number, contains the product, and the per-product photo limit is not reached.
const ORIGINS=['https://clayxculture.in','https://www.clayxculture.in'];
const okO=(o:string)=>ORIGINS.includes(o)||/^https:\/\/[a-z0-9-]+\.(pages\.dev|netlify\.app)$/.test(o);
const hex=(b:ArrayBuffer)=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');
Deno.serve(async(req:Request)=>{
 const o=req.headers.get('origin')||'';
 const h={'Access-Control-Allow-Origin':okO(o)?o:ORIGINS[0],'Access-Control-Allow-Headers':'content-type,apikey','Access-Control-Allow-Methods':'POST,OPTIONS','Vary':'Origin','Content-Type':'application/json'};
 const out=(b:unknown,s=200)=>new Response(JSON.stringify(b),{status:s,headers:h});
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:h});
 if(req.method!=='POST'||!okO(o))return out({error:'forbidden'},403);
 let b:any;try{b=await req.json()}catch{return out({error:'bad_request'},400)}
 const c=String(b.c||'').slice(0,20),ph=String(b.ph||'').replace(/\D/g,'').slice(-10),pid=Number(b.pid);
 if(!c||ph.length!==10||!Number.isInteger(pid))return out({error:'bad_request'},400);
 const key=Deno.env.get('SUPABASE_ANON_KEY')||'';
 const r=await fetch(Deno.env.get('SUPABASE_URL')+'/rest/v1/rpc/review_check',{method:'POST',headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify({c,ph,pid})});
 const chk=r.ok?await r.json():null;
 if(!chk||chk.ok!==true||chk.photo!==true)return out({error:'not_allowed'},403);
 const secret=Deno.env.get('CLOUDINARY_API_SECRET'),apiKey=Deno.env.get('CLOUDINARY_API_KEY'),cloud=Deno.env.get('CLOUDINARY_CLOUD_NAME')||'soa4brgh';
 if(!secret||!apiKey)return out({error:'not_configured'},500);
 const ts=Math.floor(Date.now()/1000),folder='calyx/r',af='jpg,png,webp';
 const sig=hex(await crypto.subtle.digest('SHA-1',new TextEncoder().encode('allowed_formats='+af+'&folder='+folder+'&timestamp='+ts+secret)));
 return out({signature:sig,timestamp:ts,api_key:apiKey,cloud_name:cloud,folder,allowed_formats:af});
});
